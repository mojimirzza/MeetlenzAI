# MeetLens — Meeting Question Intelligence

A local-first application that turns noisy meeting questions into a small set of high-value, non-duplicate questions that a human moderator can approve and ask.

## Product vocabulary

Your original idea maps to these standard concepts:

- **Meeting Session**: the current meeting state, title, agenda, topic/domain, participant expertise, and permissions.
- **Question Intake**: typed or transcribed participant questions.
- **Semantic Clustering / Deduplication**: grouping near-duplicate questions into intent-level categories.
- **Question Canonicalization**: producing a minimal, precise representative question for each intent.
- **Nomination Set**: 2+ candidate canonical questions per category.
- **Human-in-the-Loop (HITL) Moderation**: the moderator approves one nominee per category, or edits/rejects it.
- **Priority Agent**: a narrow, policy-bounded agent that orders categories using explainable KPIs.
- **Relevance Scoring / Learning-to-Rank (LTR)**: combines meeting relevance, frequency, likes, expertise fit, novelty, and age.
- **Privacy Boundary**: controls what participant-level information can be shown to other participants.

## Architecture

```text
Participant clients
        |
        v
  FastAPI / WebSocket
        |
  Meeting State Store (SQLite MVP -> Postgres)
        |
  +-----+-----------------------+
  |                             |
  v                             v
Question Pipeline           Audio Pipeline
  |                             |
  +--> normalize                +--> ASR (faster-whisper)
  +--> semantic embed           +--> diarization (pyannote)
  +--> cluster                  +--> transcript segments
  +--> canonicalize
  +--> nominate 2+
  +--> KPI scoring
  +--> priority agent
  |
  v
Moderator HITL Queue
  |
  +--> approve / edit / reject
  |
  v
Question asked in meeting

LLM: OpenAI-compatible local endpoint (DeepSeek-V4-Flash / another local model)
Vector: sklearn MVP; replace with pgvector or Qdrant at scale
```

DeepSeek V4 is current as of this project snapshot; DeepSeek describes V4-Pro and V4-Flash, and V4-Flash is available as open weights. The official model card shows use through Transformers, vLLM, or SGLang. citeturn516831search3turn516831search1

DeepSeek Harness (`dsh`) is useful for developing and operating agents, but it is a separate developer-preview agent harness. It is not required as the application's serving runtime. citeturn766573search0turn766573search3

## Run

### 1. Local Python MVP without a local LLM

This uses deterministic fallbacks so the UI and ranking pipeline can be tested immediately.

```bash
python -m venv .venv
source .venv/bin/activate  # Windows: .venv\\Scripts\\activate
pip install -e '.[dev]'
python -m app.main
```

Open `http://localhost:8000`.

### 2. Attach a local LLM

Run any OpenAI-compatible local server. For DeepSeek-V4-Flash, the model card documents vLLM and SGLang serving. citeturn516831search1

Then set:

```env
LLM_BASE_URL=http://localhost:8001/v1
LLM_MODEL=deepseek-ai/DeepSeek-V4-Flash
LLM_API_KEY=local
```

### 3. Audio

Install optional audio dependencies:

```bash
pip install -e '.[audio]'
```

The ASR adapter uses faster-whisper. Speaker diarization can be enabled separately with pyannote.audio. The current pyannote Community-1 pipeline is Python-first and can run locally/offline after model preparation; its docs also note that streaming diarization itself is not provided by pyannote.audio, so the MVP treats uploaded/short audio chunks as the safe boundary. citeturn980001search0turn980001search3turn980001search4

## Ranking model

The MVP uses an explainable score rather than pretending a black-box ranker is already trained:

`priority = 0.30*meeting_relevance + 0.22*frequency + 0.18*likes + 0.12*expertise_fit + 0.10*novelty + 0.08*recency`

Weights are configurable in `app/core/config.py`.

For a production version, log outcomes and train a learning-to-rank model against moderator choices and meeting outcomes. Qdrant and pgvector are both viable upgrades for hybrid semantic + lexical retrieval; pgvector supports HNSW and hybrid PostgreSQL full-text search, while Qdrant supports dense+sparse hybrid retrieval and RRF/DBSF fusion. citeturn692479search0turn692479search2turn692479search3

## Prompt engineering strategy

Prompts are versioned in `prompts/` and use typed JSON contracts:

1. **Contract-first output** — Pydantic schema is the source of truth.
2. **Decomposition** — classify/cluster, canonicalize, then nominate; do not ask one prompt to do the entire pipeline.
3. **Evidence anchoring** — every candidate stores source question IDs and confidence.
4. **Candidate diversity** — nominees must be semantically distinct enough to justify two choices.
5. **Deterministic policy layer** — KPI ordering happens in Python and is never delegated blindly to the LLM.
6. **Human gate** — only moderator-approved questions can reach `ASKED`.
7. **Evaluation** — retain prompt version, model, latency, scores, human decision, and outcome for offline evals.

## Privacy / Netherlands positioning

The product should be positioned as **local-first meeting intelligence** rather than a cloud transcription service. This matters for enterprise adoption because meeting audio and questions can be sensitive.

For the Dutch startup residence route, the IND currently states that a startup must be innovative, the founder must have an active role, and the startup residence permit is normally valid for up to one year; the RVO route also requires a facilitator and a step-by-step plan. This project therefore includes an innovation/value proposition section below, but immigration eligibility must be checked against the latest IND/RVO rules for your exact situation. citeturn900006search3turn900006search11turn900006search1

### Suggested Dutch startup positioning

**MeetLens: Privacy-preserving real-time question intelligence for high-stakes meetings.**

The stronger differentiator is not “AI summarizes meetings.” It is:

> “MeetLens turns hundreds of human questions into a small, auditable, representative set of questions a moderator can approve in real time — while keeping sensitive meeting data local.”

That gives a clearer enterprise wedge into board meetings, public-sector consultations, town halls, product discovery, expert panels, regulated industries, and multilingual European meetings.

## Production hardening still needed

This repository is an MVP foundation, not a finished commercial SaaS. Before paid pilots: authentication/SSO, TLS, per-meeting authorization, immutable audit log, retention policies, consent UX, encrypted storage, multi-tenant isolation, PostgreSQL, proper WebRTC/browser audio capture, observability, load tests, model governance, accessibility, Dutch/EU legal review, and independent security review.


## Pilot execution

Run the deterministic pilot demo without any cloud model:

```bash
python scripts/benchmark.py
python scripts/demo_pilot.py
```

The demo exercises question intake, semantic grouping, nominee generation, priority ordering, moderator approval, outcome capture, and evidence reporting. The benchmark is a small sanity fixture, not production accuracy.

See `docs/STRATEGY_DECISION.md`, `docs/PRODUCT_MISSION.md`, `docs/PILOT_ARCHITECTURE.md`, `docs/EVIDENCE_PLAN.md`, `docs/REQUIREMENT_TRACEABILITY.md`, and `docs/DECISION_ENGINE_EXECUTION.md`.

## Zero Pilot

Run the controlled evidence scenario without a cloud model:

```bash
python scripts/zero_pilot.py
```

The output is written to `artifacts/zero_pilot/` and explicitly labels the result as synthetic controlled evidence. It is not external customer validation.

## Blind Spot Radar

`GET /api/meetings/{meeting_id}/coverage` returns evidence-backed coverage signals based on declared participant expertise and submitted question expertise. The moderator remains the decision maker.

## Architecture — Modular Monolith

MeetLens uses a modular-monolith shape: feature-oriented application code, explicit dependency injection through `app/bootstrap`, small stable ports in `app/kernel`, and dependency-free resilience primitives in `app/platform`. The product remains one deployable process; microservices are intentionally deferred until independent scaling/deployment/reliability boundaries become real.

See `docs/ARCHITECTURE_MODULAR_MONOLITH.md`.
